<?php 
/*
Plugin Name: Disable Cart Fragments
Plugin URI: https://www.sertmedia.com
Description: Disables the WooCommerce Cart Fragments from loading and slowing down your website.  
Version: 1.0
Author: SERTMedia
Author URI: https://www.sertmedia.com
*/

/** Disable Ajax Call from WooCommerce */
function sert_dequeue_woocommerce_cart_fragments() { 
	wp_dequeue_script('wc-cart-fragments'); 
}

add_action( 'wp_enqueue_scripts', 'sert_dequeue_woocommerce_cart_fragments', PHP_INT_MAX); 
